// Back to Top Button Script

// Create button dynamically
const backToTopBtn = document.createElement("button");
backToTopBtn.id = "backToTop";
backToTopBtn.textContent = "↑";
document.body.appendChild(backToTopBtn);

// Style button (optional inline styling, can move to CSS)
backToTopBtn.style.display = "none";
backToTopBtn.style.position = "fixed";
backToTopBtn.style.bottom = "30px";
backToTopBtn.style.right = "30px";
backToTopBtn.style.zIndex = "99";
backToTopBtn.style.border = "none";
backToTopBtn.style.outline = "none";
backToTopBtn.style.backgroundColor = "#0077ff";
backToTopBtn.style.color = "white";
backToTopBtn.style.cursor = "pointer";
backToTopBtn.style.padding = "12px 16px";
backToTopBtn.style.borderRadius = "6px";
backToTopBtn.style.fontSize = "18px";
backToTopBtn.style.boxShadow = "0 2px 8px rgba(0,0,0,0.2)";
backToTopBtn.style.transition = "background 0.3s";

// Show button when scrolled down
window.addEventListener("scroll", () => {
  if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
    backToTopBtn.style.display = "block";
  } else {
    backToTopBtn.style.display = "none";
  }
});

// Scroll smoothly to top when clicked
backToTopBtn.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});
